<?php include'index.php'?>
<?php
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "parking";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$currentUsername = $_SESSION['username'];

// Fetch user data
$userDataQuery = "SELECT * FROM users WHERE username = '$currentUsername'";
$userDataResult = $conn->query($userDataQuery);
$userData = $userDataResult->fetch_assoc();

// Fetch vehicle data for the user
$vehicleDataQuery = "SELECT * FROM vehicles1 WHERE username = '$currentUsername'";
$vehicleDataResult = $conn->query($vehicleDataQuery);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['updateVehicle'])) {
        // Update vehicle details
        $vehicleId = $conn->real_escape_string($_POST['vehicleId']);
        $vehicleRegNumber = $conn->real_escape_string($_POST['vehicleRegNumber']);
        $vehicleName = $conn->real_escape_string($_POST['vehicleName']);
        $contact = $conn->real_escape_string($_POST['contact']);

        $updateVehicleQuery = "
            UPDATE vehicles1
            SET vehicleRegNumber = '$vehicleRegNumber', 
                vehicleName = '$vehicleName', contact = '$contact' 
            WHERE id = '$vehicleId' AND username = '$currentUsername'";
        $conn->query($updateVehicleQuery);
        header("Location: change_profile.php?success=1");
        exit();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        form {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background: #f7f7f7;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin: 10px 0 5px;
            color: black;
        }

        input[type="text"], button {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        button {
            background: #333;
            color: #fff;
            cursor: pointer;
        }

        button:hover {
            background: #555;
        }

        .success {
            color: green;
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<h2 style="text-align: center;">Change Profile</h2>



<h3 style="text-align: center;">Update Vehicle Details</h3>

<?php while ($vehicleData = $vehicleDataResult->fetch_assoc()): ?>
    <form method="post">
        <input type="hidden" name="vehicleId" value="<?= htmlspecialchars($vehicleData['id']); ?>">
        <label for="vehicleRegNumber">Vehicle Register Number:</label>
        <input type="text" id="vehicleRegNumber" name="vehicleRegNumber" value="<?= htmlspecialchars($vehicleData['vehicleRegNumber']); ?>" required>

        <label for="vehicleName">Vehicle Name:</label>
        <input type="text" id="vehicleName" name="vehicleName" value="<?= htmlspecialchars($vehicleData['vehicleName']); ?>" required>

        <label for="contact">Contact:</label>
        <input type="text" id="contact" name="contact" value="<?= htmlspecialchars($vehicleData['contact']); ?>" required>

        <button type="submit" name="updateVehicle">Update Vehicle</button>
    </form>
<?php endwhile; ?>

</body>
</html>
<?php if (isset($_GET['success'])): ?>
   <p class="success">Vehicle details updated successfully!</p>
    
<?php endif; ?>