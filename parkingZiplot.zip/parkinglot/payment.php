<?php include 'index.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Management System - Two-Wheeler Slots</title>
    <style>
        /* Parking Lot Grid */
        .parking-lot {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 20px;
            row-gap: 80px;
            padding: 20px;
        }

        /* Styling for each parking slot */
        .slot {
            position: relative;
            width: 80px;
            height: 20px;
            background-color: #3a3a3a;
            color: white;
            text-align: center;
            border-radius: 5px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.3s ease;
        }

        .slot:hover, .slot:hover::before, .slot:hover::after, .slot:hover .handlebar, .slot:hover .seat {
            background-color: #4caf50;
        }

        /* Wheels */
        .slot::before, .slot::after {
            content: "";
            position: absolute;
            width: 16px;
            height: 16px;
            background-color: black;
            border-radius: 70%;
            bottom: -10px;
        }

        .slot::before {
            left: -18px;
        }

        .slot::after {
            right: -18px;
        }

        /* Handlebar */
        .handlebar {
            position: absolute;
            top: -10px;
            width: 10px;
            height: 4px;
            background-color: #3a3a3a;
            border-radius: 1px;
            left: 15px;
        }

        /* Seat */
        .seat {
            position: absolute;
            top: -5px;
            width: 16px;
            height: 6px;
            background-color: #3a3a3a;
            border-radius: 3px;
            right: 10px;
        }

        /* Booked slot styling */
        .booked {
            background-color: red;
            cursor: not-allowed;
        }

        .booked::before, .booked::after, .booked .handlebar, .booked .seat {
            background-color: red;
        }

        /* Form Styling */
        .form-container {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: rgba(94, 92, 92, 0.9);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            color: white;
            z-index: 1000;
            width: 400px;
            max-width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .form-container input, .form-container select, .form-container button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            background: white;
            color: black;
        }

        .form-container button {
            background-color: #333;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }

        .form-container button:hover {
            background-color: #555;
        }

    
    </style>
</head>

<body>

<h2 style="text-align: center;">Two-Wheeler Parking Slots</h2>

<div class="parking-lot">
    <?php
    $conn = new mysqli("localhost", "root", "", "parking");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $result = $conn->query("SELECT slot FROM vehicles");
    $bookedSlots = [];

    while ($row = $result->fetch_assoc()) {
        $bookedSlots[] = $row['slot'];
    }
  
    for ($i = 1; $i<=25; $i++):
        $slotId = "Slot $i";
        $isBooked = in_array($slotId, $bookedSlots);
        $slotClass = $isBooked ? 'slot booked' : 'slot';
        $onclick = $isBooked ? '' : "onclick=\"openVehicleForm('$slotId')\"";
        ?>
        <div class="<?= $slotClass ?>" <?= $onclick ?>>
            <?= $slotId ?>
            <div class="handlebar"></div>
            <div class="seat"></div>
        </div>
        
    <?php endfor; ?>

    <?php $conn->close(); ?>

</div>

<!-- Vehicle Form -->
<div id="vehicleForm" class="form-container">
    <h3>Vehicle Details</h3>
    <form id="vehicleDetailsForm">
        <input type="hidden" id="selectedSlot" name="slot">
        <label for="vehicleRegNumber">Vehicle Register Number</label>
        <input type="text" id="vehicleRegNumber" name="vehicleRegNumber" required>
        <label for="vehicleName">Vehicle Name</label>
        <input type="text" id="vehicleName" name="vehicleName" required>
        <label for="contact">Contact</label>
        <input type="text" id="contact" name="contact" required>
        <label for="date">Date</label>
        <input type="date" id="date" name="date" required>
        <label for="entryTime">Entry Time</label>
        <input type="time" id="entryTime" name="entryTime" required>
        <label for="exitTime">Exit Time</label>
        <input type="time" id="exitTime" name="exitTime" required>
        <label for="totalAmount">Total Amount (Rs.)</label>
        <input type="text" id="totalAmount" name="totalAmount" readonly>
        <button type="button" onclick="calculateAmount()">Calculate Amount</button>
        <button type="button" onclick="openPaymentForm()">Next</button>
        <button type="button" onclick="closeForm('vehicleForm')">Cancel</button>
    </form>
</div>

<!-- Payment Form -->
<div id="paymentForm" class="form-container">
    <h3>Payment Method</h3>
    <form id="paymentDetailsForm" action="vechicledb1.php" method="POST">
        <input type="hidden" id="finalSlot" name="slot">
        <input type="hidden" id="finalVehicleRegNumber" name="vehicleRegNumber">
        <input type="hidden" id="finalVehicleName" name="vehicleName">
        <input type="hidden" id="finalContact" name="contact">
        <input type="hidden" id="finalDate" name="date">
        <input type="hidden" id="finalTime" name="time">
        <label for="paymentMethod">Select Payment Method:</label>
        <select id="paymentMethod" name="paymentMethod" onchange="updateFormAction()" required>
        <option value="Cash">Cash</option>
        <option value="eSewa">khalti</option>
        </select>
        <button type="submit">Submit Booking</button>
        <button type="button" onclick="closeForm('paymentForm')">Cancel</button>
    </form>
</div>

<script>
function calculateAmount() {
        const entryTime = document.getElementById('entryTime').value;
        const exitTime = document.getElementById('exitTime').value;

        if (entryTime && exitTime) {
            const entryDate = new Date(`1970-01-01T${entryTime}:00`);
            const exitDate = new Date(`1970-01-01T${exitTime}:00`);

            if (exitDate > entryDate) {
                const duration = (exitDate - entryDate) / (1000 * 60 * 60); // Convert milliseconds to hours
                const ratePerHour = 50; // Example rate per hour
                const totalAmount = Math.ceil(duration) * ratePerHour;

                document.getElementById('totalAmount').value = totalAmount;
            } else {
                alert('Exit time must be after entry time.');
                document.getElementById('totalAmount').value = '';
            }
        } else {
            alert('Please fill both entry and exit times.');
        }
    }



    function updateFormAction() {
    const paymentMethod = document.getElementById('paymentMethod').value;
    const paymentForm = document.getElementById('paymentDetailsForm');

    if (paymentMethod === 'eSewa') {
        paymentForm.action = 'payment_process.php'; // Link to Khalti payment process file
    } else {
        paymentForm.action = 'vechicledb1.php'; // Default action for other methods
    }
}




    function openPaymentForm() {
        // Copy values from vehicle form to payment form
        document.getElementById('finalSlot').value = document.getElementById('selectedSlot').value;
        document.getElementById('finalVehicleRegNumber').value = document.getElementById('vehicleRegNumber').value;
        document.getElementById('finalVehicleName').value = document.getElementById('vehicleName').value;
        document.getElementById('finalContact').value = document.getElementById('contact').value;
        document.getElementById('finalDate').value = document.getElementById('date').value;
        document.getElementById('finalTime').value = document.getElementById('entryTime').value;

        // Add calculated total amount to the payment form
        const totalAmount = document.getElementById('totalAmount').value;
        if (!totalAmount) {
            alert('Please calculate the total amount before proceeding.');
            return;
        }

        const paymentForm = document.getElementById('paymentDetailsForm');
        const amountField = document.createElement('input');
        amountField.type = 'hidden';
        amountField.name = 'totalAmount';
        amountField.value = totalAmount;
        paymentForm.appendChild(amountField);

        document.getElementById('vehicleForm').style.display = 'none';
        document.getElementById('paymentForm').style.display = 'block';
    }
    function openVehicleForm(slot) {
        document.getElementById('selectedSlot').value = slot;
        document.getElementById('vehicleForm').style.display = 'block';
    }
    function closeForm(formId) {
        document.getElementById(formId).style.display = 'none';
    }
</script>

</body>
</html>