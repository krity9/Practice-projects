<?php include 'admindash.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Management System - Two-Wheeler Slots</title>
    <style>
        /* Parking Lot Grid */
        .parking-lot {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 20px;
            row-gap: 80px;
            column-gap: 80px;
            padding: 20px;
        }

        /* Styling for each parking slot */
        .slot {
            position: relative;
            top:70px;
            width: 80px;
            height: 20px;
            background-color: #3a3a3a;
            color: white;
            text-align: center;
            border-radius: 5px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.3s ease;
        }

        .slot:hover, .slot:hover::before, .slot:hover::after, .slot:hover .handlebar, .slot:hover .seat {
            background-color: #4caf50;
        }

        /* Wheels */
        .slot::before, .slot::after {
            content: "";
            position: absolute;
            width: 16px;
            height: 16px;
            background-color: black;
            border-radius: 70%;
            bottom: -10px;
        }

        .slot::before {
            left: -18px;
        }

        .slot::after {
            right: -18px;
        }

        /* Handlebar */
        .handlebar {
            position: absolute;
            top: -10px;
            width: 10px;
            height: 4px;
            background-color: #3a3a3a;
            border-radius: 1px;
            left: 15px;
        }

        /* Seat */
        .seat {
            position: absolute;
            top: -5px;
            width: 16px;
            height: 6px;
            background-color: #3a3a3a;
            border-radius: 3px;
            right: 10px;
        }

        /* Booked slot styling */
        .slot.booked {
            background-color: red; /* Color for booked slots */
            cursor: not-allowed;
        }

        /* Available slot styling */
        .slot.available {
            background-color: #3a3a3a; /* Default color for available slots */
        }

        .slot.available:hover {
            background-color: #4caf50; /* Highlight on hover */
        }

        /* Tooltip for booked slots */
        .tooltip {
    position: absolute;
    top: -60px; /* Adjust the position as needed */
    left: 50%;
    transform: translateX(-50%);
    background-color: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 10px;
    border-radius: 5px;
    font-size: 12px;
    display: none;
    z-index: 10;
    text-align: left;
}

.slot.booked:hover .tooltip {
    display: block;
}


    
    </style>
</head>

<body>

<h2 style="text-align: center; color:#333;">Two-Wheeler Parking Slots</h2>

<div class="parking-lot">
<?php
    // Database connection
    $conn = new mysqli("localhost", "root", "", "parking");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the current date
    $currentDate = date('Y-m-d');

    // Fetch booked slots with vehicle details
    $result = $conn->query("
        SELECT slot, booked_date, vehicleRegNumber, username, contact 
        FROM vehicles1 
        WHERE booked_date >= '$currentDate'
    ");
    $bookedSlots = [];

    // Store booked slots and their details
    while ($row = $result->fetch_assoc()) {
        $bookedSlots[$row['slot']] = [
            'booked_date' => $row['booked_date'],
            'vehicleRegNumber' => $row['vehicleRegNumber'],
            'username' => $row['username'],
            'contact' => $row['contact'],
        ];
    }

    // Render parking slots
    for ($i = 1; $i <= 25; $i++):
        $slotId = "Slot t$i";
        $isBooked = isset($bookedSlots[$slotId]);
        $slotClass = $isBooked ? 'slot booked' : 'slot available';
        $onclick = $isBooked ? '' : "onclick=\"openVehicleForm('$slotId')\"";

        // Prepare tooltip content
        $tooltipContent = $isBooked
            ? "Booked by: " . htmlspecialchars($bookedSlots[$slotId]['username']) . "<br>" .
              "Contact: " . htmlspecialchars($bookedSlots[$slotId]['contact']) . "<br>" .
              "Vehicle No: " . htmlspecialchars($bookedSlots[$slotId]['vehicleRegNumber']) . "<br>" .
              "Until: " . htmlspecialchars($bookedSlots[$slotId]['booked_date'])
            : "Available to book";
    ?>
        <div class="<?= $slotClass ?>" <?= $onclick ?>>
            <?= $slotId ?>
            <?php if ($isBooked): ?>
                <div class="tooltip"><?= $tooltipContent ?></div>
            <?php endif; ?>
        </div>
    <?php endfor; ?>

    <?php $conn->close(); ?>
</div>


<script>

function openVehicleForm(slot) {
        alert("Booking functionality not implemented yet for: " + slot);
    }
</script>

</body>
</html>