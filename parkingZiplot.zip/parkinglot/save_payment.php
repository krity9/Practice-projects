<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Management System - Two-Wheeler Slots</title>
    <style>
        .parking-lot {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 20px;
            padding: 20px;
        }

        /* Styling for a two-wheeler vehicle */
        .slot {
            position: relative;
            width: 80px;
            height: 20px;
            background-color: #3a3a3a; /* Bike body */
            color: white;
            text-align: center;
            border-radius: 5px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.3s ease;
        }

        .slot:hover, .slot:hover::before, .slot:hover::after, .slot:hover .handlebar, .slot:hover .seat {
            background-color: #4caf50;
        }

        /* Wheels */
        .slot::before, .slot::after {
            content: "";
            position: absolute;
            width: 16px;
            height: 16px;
            background-color: black;
            border-radius: 50%;
            bottom: -10px;
        }

        .slot::before {
            left: -18px; /* Left wheel */
        }

        .slot::after {
            right: -18px; /* Right wheel */
        }

        /* Handlebar */
        .handlebar {
            position: absolute;
            top: -12px;
            width: 10px;
            height: 4px;
            background-color: #3a3a3a;
            border-radius: 1px;
            left: 15px;
        }

        /* Seat */
        .seat {
            position: absolute;
            top: -5px;
            width: 16px;
            height: 6px;
            background-color: #3a3a3a;
            border-radius: 3px;
            right: 10px;
        }

        /* Booked slot styling */
        .booked {
            background-color: red;
            cursor: not-allowed;
        }

        /* Booked slot's wheels, handle, and seat */
        .booked::before, .booked::after, .booked .handlebar, .booked .seat {
            background-color: red;
        }

        /* Form styling */
        #vehicle-form {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: rgba(94, 92, 92, 0.9);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            color: white;
            z-index: 1000;
        }

        #vehicle-form input, #vehicle-form select {
            width: 100%;
            padding: 8px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        #vehicle-form button {
            background-color: #333;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }
    </style>
</head>
<?php include 'index.php'; ?>

<body>

<h2 style="text-align: center;">Two-Wheeler Parking Slots</h2>

<div class="parking-lot">
    <?php
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "parking");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch booked slots
    $result = $conn->query("SELECT slot FROM vehicles");
    $bookedSlots = [];

    while ($row = $result->fetch_assoc()) {
        $bookedSlots[] = $row['slot'];
    }

    // Loop through slots and mark booked slots
    for ($i = 1; $i <= 25; $i++):
        $slotId = "Slot $i";
        $isBooked = in_array($slotId, $bookedSlots);
        $slotClass = $isBooked ? 'slot booked' : 'slot';
        $onclick = $isBooked ? '' : "onclick=\"openForm('$slotId')\"";
    ?>
        <div class="<?= $slotClass ?>" <?= $onclick ?>>
            <?= $slotId ?>
            <div class="handlebar"></div>
            <div class="seat"></div>
        </div>
    <?php endfor; ?>

    <?php $conn->close(); ?>
</div>

<div id="vehicle-form">
    <h3>Vehicle Details</h3>
    <form action="vehicledb1.php" method="post">
        <input type="hidden" id="selectedSlot" name="slot">
        <div>
            <label for="vehicleRegNumber">Vehicle Register Number</label>
            <input type="text" id="vehicleRegNumber" name="vehicleRegNumber" required>
        </div>
  
        <div>
            <label for="vehicleName">Vehicle Name</label>
            <input type="text" id="vehicleName" name="vehicleName" required>
        </div>
        <div>
            <label for="ownerName">Owner Name</label>
            <input type="text" id="ownerName" name="ownerName" required>
        </div>
        <div>
            <label for="contact">Contact</label>
            <input type="text" id="contact" name="contact" required>
        </div>
        <div>
            <label for="date">Date</label>
            <input type="date" id="date" name="date" required>
        </div>
        <div>
            <label for="time">Time</label>
            <input type="time" id="time" name="time" required>
        </div>
        <button type="submit">Book Slot</button>
        <button type="button" onclick="closeForm()">Cancel</button>
    </form>
</div>

<script>
    function openForm(slot) {
        document.getElementById('selectedSlot').value = slot;
        document.getElementById('vehicle-form').style.display = 'block';
    }

    function closeForm() {
        document.getElementById('vehicle-form').style.display = 'none';
    }
</script>

</body>
</html>
