<?php include 'admindash.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            padding-top: 70px;
            background-color: #f4f4f4;
            min-height: 100vh;
            box-sizing: border-box;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        table th {
            background-color: #333;
            color: white;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #ddd;
        }

        .no-data {
            text-align: center;
            color: #555;
            margin-top: 20px;
        }

        .clickable {
            color: blue;
            text-decoration: underline;
            cursor: pointer;
        }

        .clickable:hover {
            text-decoration: none;
        }
    </style>
    <script>
        function updatePaymentStatus(id) {
            const confirmed = confirm("Are you sure you want to mark this as Paid?");
            if (!confirmed) return;

            fetch('update_payment_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: id })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById(`payment-status-${id}`).textContent = 'Paid';
                    document.getElementById(`payment-status-${id}`).classList.remove('clickable');
                } else {
                    alert('Failed to update payment status.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        }
    </script>
</head>

<body>
    <div class="main-content">
        <h1>Current Parking Details</h1>

        <?php
        // Database connection
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "parking";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to fetch current booked slots
        $sql = "SELECT * FROM vehicles1 WHERE (exitDateTime IS NULL OR CURDATE() BETWEEN booked_date AND exitDateTime) ORDER BY booked_date DESC";
        $result = $conn->query($sql);

        if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Vehicle Number</th>
                        <th>Owner Name</th>
                        <th>Slot Number</th>
                        <th>Booking Date</th>
                        <th>Payment Method</th>
                        <th>Payment Status</th>

                    </tr>
                </thead>
                <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <td><?= htmlspecialchars($row['vehicleRegNumber']) ?></td>
            <td><?= htmlspecialchars($row['username']) ?></td>
            <td><?= htmlspecialchars($row['slot']) ?></td>
            <td><?= htmlspecialchars($row['booked_date']) ?></td>
            <td><?= htmlspecialchars($row['paymentMethod']) ?></td>
            <td>
                <?php if ($row['paymentMethod'] === 'eSewa'): ?>
                    <span id="payment-status-<?= $row['id'] ?>">Paid</span>
                <?php else: ?>
                    <?php if ($row['payment_status'] === 'Paid'): ?>
                        <span id="payment-status-<?= $row['id'] ?>">Paid</span>
                    <?php else: ?>
                        <span id="payment-status-<?= $row['id'] ?>" class="clickable" onclick="updatePaymentStatus(<?= $row['id'] ?>)">Unpaid</span>
                    <?php endif; ?>
                <?php endif; ?>
            </td>
        </tr>
    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="no-data">No active bookings at the moment.</p>
        <?php
        endif;

        // Close connection
        $conn->close();
        ?>
    </div>
</body>
</html>
