<?php
$conn = new mysqli("localhost", "root", "", "parking");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $slot = $_POST['slot'];
    $vehicleRegNumber = $_POST['vehicleRegNumber'];
    $startTime = $_POST['entryTime'];
    $endTime = $_POST['exitTime'];

    $stmt = $conn->prepare("INSERT INTO booked (slot, vehicleRegNumber, startTime, endTime) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $slot, $vehicleRegNumber, $startTime, $endTime);

    if ($stmt->execute()) {
        header("Location: payment.php");
        exit();    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
