<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
     main {
  padding: 100px 20px;
  color: white;
  text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.7);
 
}
body{
  background-image: url('image/bg2.jpg');
  background-size: cover;
  background-attachment: fixed;
  background-position: center;

}
     </style>
</head>
<body>
    <?php include'homepage.php';?>
<main>
    <section id="home">
      <h1>Welcome to the Parking Management System</h1>
      <p>Manage and monitor your parking spaces efficiently.</p>
    </section>

    <section id="parking">
      <h2>Parking System Overview</h2>
      <p>Real-time parking management with easy access and control.</p>
    </section>
  </main>
  </body>
</html>