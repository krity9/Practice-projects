<?php include 'index.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Management System - Two-Wheeler Slots</title>
    <style>
        /* Parking Lot Grid */
        .parking-lot {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 20px;
            row-gap: 80px;
            padding: 20px;
        }

        /* Styling for each parking slot */
        .slot {
            position: relative;
            width: 80px;
            height: 20px;
            background-color: #3a3a3a;
            color: white;
            text-align: center;
            border-radius: 5px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.3s ease;
        }

        .slot:hover, .slot:hover::before, .slot:hover::after, .slot:hover .handlebar, .slot:hover .seat {
            background-color: #4caf50;
        }

        /* Wheels */
        .slot::before, .slot::after {
            content: "";
            position: absolute;
            width: 16px;
            height: 16px;
            background-color: black;
            border-radius: 70%;
            bottom: -10px;
        }

        .slot::before {
            left: -18px;
        }

        .slot::after {
            right: -18px;
        }

        /* Handlebar */
        .handlebar {
            position: absolute;
            top: -10px;
            width: 10px;
            height: 4px;
            background-color: #3a3a3a;
            border-radius: 1px;
            left: 15px;
        }

        /* Seat */
        .seat {
            position: absolute;
            top: -5px;
            width: 16px;
            height: 6px;
            background-color: #3a3a3a;
            border-radius: 3px;
            right: 10px;
        }

        /* Booked slot styling */
        .slot.booked {
            background-color: red; /* Color for booked slots */
            cursor: not-allowed;
        }

        /* Available slot styling */
        .slot.available {
            background-color: #3a3a3a; /* Default color for available slots */
        }

        .slot.available:hover {
            background-color: #4caf50; /* Highlight on hover */
        }

        /* Tooltip for booked slots */
        .tooltip {
            position: absolute;
            top: -25px;
            background-color: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 5px;
            border-radius: 3px;
            font-size: 12px;
            display: none;
        }

        .slot.booked:hover .tooltip {
            display: block;
        }

        /* Form Styling */
        .form-container {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: rgba(94, 92, 92, 0.9);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            color: white;
            z-index: 1000;
            width: 400px;
            max-width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .form-container input, .form-container select, .form-container button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            background: white;
            color: black;
        }

        .form-container button {
            background-color: #333;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }

        .form-container button:hover {
            background-color: #555;
        }

    
    </style>
</head>

<body>

<h2 style="text-align: center; color:#333;">Two-Wheeler Parking Slots</h2>

<div class="parking-lot">
<?php
    // Database connection
    $conn = new mysqli("localhost", "root", "", "parking");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the current date
    $currentDate = date('Y-m-d');

    // Fetch booked slots with a valid date
    $result = $conn->query("SELECT slot, booked_date FROM vehicles1 WHERE booked_date >= '$currentDate'");
    $bookedSlots = [];

    // Store booked slots and their booking dates
    while ($row = $result->fetch_assoc()) {
        $bookedSlots[$row['slot']] = $row['booked_date'];
    }

    // Render parking slots
    for ($i = 1; $i <= 25; $i++):
        $slotId = "Slot t$i";
        $isBooked = isset($bookedSlots[$slotId]);
        $slotClass = $isBooked ? 'slot booked' : 'slot available';
        $onclick = $isBooked ? '' : "onclick=\"openVehicleForm('$slotId')\"";
    ?>
        <div class="<?= $slotClass ?>" <?= $onclick ?> title="<?= $isBooked ? 'Slot is booked' : 'Click to book' ?>">
            <?= $slotId ?>
            <?php if ($isBooked): ?>
                <div class="tooltip">Booked until <?= $bookedSlots[$slotId] ?></div>
            <?php endif; ?>
        </div>
    <?php endfor; ?>

    <?php $conn->close(); ?>
</div>
<!-- Vehicle Form -->
<div id="vehicleForm" class="form-container">
    <h3>Vehicle Details</h3>
    <form id="vehicleDetailsForm">
        <input type="hidden" id="selectedSlot" name="slot">
        <label for="vehicleRegNumber">Vehicle Register Number</label>
        <input type="text" id="vehicleRegNumber" name="vehicleRegNumber" required>
        
        <label for="vehicleName">Vehicle Name</label>
        <input type="text" id="vehicleName" name="vehicleName" required>
        
        <label for="contact">Contact</label>
        <input type="text" id="contact" name="contact" required>
        
        <label for="entryDateTime">Entry Date & Time</label>
        <input type="datetime-local" id="entryDateTime" name="entryDateTime" required>
        
        <label for="exitDateTime">Exit Date & Time</label>
        <input type="datetime-local" id="exitDateTime" name="exitDateTime" required>
        
        <label for="totalAmount">Total Amount (Rs.)</label>
        <input type="text" id="totalAmount" name="totalAmount" readonly>
        
        <button type="button" onclick="calculateAmount()">Calculate Amount</button>
        <button type="button" onclick="openPaymentForm()">Next</button>
        <button type="button" onclick="closeForm('vehicleForm')">Cancel</button>
    </form>
</div>

<div id="paymentForm" class="form-container">
    <h3>Payment Method</h3>
    <form id="paymentDetailsForm" action="vehicledb1.php" method="POST">
        <input type="hidden" id="finalSlot" name="slot">
        <input type="hidden" id="finalVehicleRegNumber" name="vehicleRegNumber">
        <input type="hidden" id="finalVehicleName" name="vehicleName">
        <input type="hidden" id="finalContact" name="contact">
        <input type="hidden" id="finalEntryDateTime" name="entryDateTime">
        <input type="hidden" id="finalExitDateTime" name="exitDateTime">
        <input type="hidden" id="finalTotalAmount" name="totalAmount">
        
        <label for="paymentMethod">Select Payment Method:</label>
        <select id="paymentMethod" name="paymentMethod" onchange="updateFormAction()"required>
            <option value="Cash">Cash</option>
            <option value="eSewa">Khalti</option>
        </select>
        
        <div id="cashMessage" style="display: none;">Please pay the parking fee at the counter.</div>
        
        <button type="submit">Submit Booking</button>
        <button type="button" onclick="closeForm('paymentForm')">Cancel</button>
    </form>
</div>
<script>
function calculateAmount() {
    const entryDateTime = document.getElementById('entryDateTime').value;
    const exitDateTime = document.getElementById('exitDateTime').value;

    if (entryDateTime && exitDateTime) {
        const entryDate = new Date(entryDateTime);
        const exitDate = new Date(exitDateTime);

        if (exitDate > entryDate) {
            const duration = (exitDate - entryDate) / (1000 * 60 * 60); // Convert milliseconds to hours
            const ratePerHour = 50; // Example rate per hour
            const totalAmount = Math.ceil(duration) * ratePerHour;

            document.getElementById('totalAmount').value = totalAmount;
        } else {
            alert('Exit date-time must be after entry date-time.');
        }
    } else {
        alert('Please fill both entry and exit date-times.');
    }
}

function updateFormAction() {
        const paymentMethod = document.getElementById('paymentMethod').value;
        const paymentForm = document.getElementById('paymentDetailsForm');
        const cashMessage = document.getElementById('cashMessage');

        if (paymentMethod === 'eSewa') {
            paymentForm.action = 'payment_process.php'; // Link to Khalti payment process file
            cashMessage.style.display = 'none'; // Hide cash message
        } else if (paymentMethod === 'Cash') {
            paymentForm.action = 'vehicledb1.php'; // Default action for cash payment
            cashMessage.style.display = 'block'; // Show cash message
        }
    }

    function validateVehicleDetailsForm() {
    const vehicleRegNumber = document.getElementById('vehicleRegNumber').value.trim();
    const vehicleName = document.getElementById('vehicleName').value.trim();
    const contact = document.getElementById('contact').value.trim();
    const entryDateTime = document.getElementById('entryDateTime').value.trim();
    const exitDateTime = document.getElementById('exitDateTime').value.trim();

    // Regular expressions for validation
    const regNumberRegex = /^[A-Z0-9-]+$/i; // Example: Alphanumeric with dashes
    const contactRegex = /^\d{10}$/; // Example: 10-digit phone number

    if (!vehicleRegNumber || !regNumberRegex.test(vehicleRegNumber)) {
        alert("Please enter a valid Vehicle Registration Number.");
        return false;
    }

    if (!vehicleName) {
        alert("Please enter a Vehicle Name.");
        return false;
    }

    if (!contact || !contactRegex.test(contact)) {
        alert("Please enter a valid 10-digit Contact Number.");
        return false;
    }

    if (!entryDateTime || !exitDateTime) {
        alert("Please select both Entry Date & Time and Exit Date & Time.");
        return false;
    }

    const entryDate = new Date(entryDateTime);
    const exitDate = new Date(exitDateTime);

    if (exitDate <= entryDate) {
        alert("Exit Date-Time must be after Entry Date-Time.");
        return false;
    }

    return true;
}

function validatePaymentDetailsForm() {
    const paymentMethod = document.getElementById('paymentMethod').value;

    if (!paymentMethod) {
        alert("Please select a Payment Method.");
        return false;
    }

    return true;
}

function openPaymentForm() {
    const selectedSlot = document.getElementById('selectedSlot').value;
    const vehicleRegNumber = document.getElementById('vehicleRegNumber').value;
    const vehicleName = document.getElementById('vehicleName').value;
    const contact = document.getElementById('contact').value;
    const entryDateTime = document.getElementById('entryDateTime').value;
    const exitDateTime = document.getElementById('exitDateTime').value;
    const totalAmount = document.getElementById('totalAmount').value;

   /* if (!selectedSlot || !vehicleRegNumber || !vehicleName || !contact || !entryDateTime || !exitDateTime || !totalAmount) {
        alert('Please complete all fields and calculate the total amount before proceeding.');
        return;
    }*/

    document.getElementById('finalSlot').value = selectedSlot;
    document.getElementById('finalVehicleRegNumber').value = vehicleRegNumber;
    document.getElementById('finalVehicleName').value = vehicleName;
    document.getElementById('finalContact').value = contact;
    document.getElementById('finalEntryDateTime').value = entryDateTime;
    document.getElementById('finalExitDateTime').value = exitDateTime;
    document.getElementById('finalTotalAmount').value = totalAmount;

    document.getElementById('vehicleForm').style.display = 'none';
    document.getElementById('paymentForm').style.display = 'block';
}
function openVehicleForm(slot) {
        document.getElementById('selectedSlot').value = slot;
        document.getElementById('vehicleForm').style.display = 'block';
    }
    function closeForm(formId) {
        document.getElementById(formId).style.display = 'none';
    }
</script>

</body>
</html>