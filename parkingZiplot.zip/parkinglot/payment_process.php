<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "parking";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Validate and sanitize user inputs
$slot = filter_input(INPUT_POST, 'slot', FILTER_SANITIZE_STRING);
$vehicleRegNumber = filter_input(INPUT_POST, 'vehicleRegNumber', FILTER_SANITIZE_STRING);
$vehicleName = filter_input(INPUT_POST, 'vehicleName', FILTER_SANITIZE_STRING);
$contact = filter_input(INPUT_POST, 'contact', FILTER_SANITIZE_STRING);
$entryDateTime = filter_input(INPUT_POST, 'entryDateTime', FILTER_SANITIZE_STRING);
$exitDateTime = filter_input(INPUT_POST, 'exitDateTime', FILTER_SANITIZE_STRING);
$paymentMethod = filter_input(INPUT_POST, 'paymentMethod', FILTER_SANITIZE_STRING);
$totalAmount = filter_input(INPUT_POST, 'totalAmount', FILTER_VALIDATE_FLOAT);
$category = filter_input(INPUT_POST, 'category', FILTER_SANITIZE_STRING) ?? 'Two-Wheeler';

// Ensure all required fields are provided
if (
    !$slot || !$vehicleRegNumber || !$vehicleName || !$contact ||
    !$entryDateTime || !$exitDateTime || !$paymentMethod || $totalAmount === false
) {
    die('Invalid input. Please fill in all required fields.');
}

// Validate entry and exit dates
if (strtotime($exitDateTime) <= strtotime($entryDateTime)) {
    die('Exit date-time must be after entry date-time.');
}

// Determine payment status
$payment_status = ($paymentMethod === 'card') ? 'paid' : 'unpaid';

// Check for slot availability
$sqlCheck = "SELECT * FROM vehicles1 WHERE slot = ? AND entryDateTime < ? AND exitDateTime > ?";
$stmtCheck = $conn->prepare($sqlCheck);
$stmtCheck->bind_param("sss", $slot, $exitDateTime, $entryDateTime);
$stmtCheck->execute();
$resultCheck = $stmtCheck->get_result();

if ($resultCheck->num_rows > 0) {
    $stmtCheck->close();
    $conn->close();
    die("The selected slot is already booked for the specified time.");
}
$stmtCheck->close();

// Check payment method and process payment
if ($paymentMethod === 'eSewa') {
    // Process payment via eSewa (or Khalti in this case)
    define('KHALTI_API_URL', 'https://a.khalti.com/api/v2/epayment/initiate/');
    define('KHALTI_SECRET_KEY', 'live_secret_key_68791341fdd94846a146f0457ff7b455');

    $paisa = intval($totalAmount * 100);
    $requestPayload = json_encode([
        'return_url' => 'http://localhost/parkinglot/twheel.php',
        'website_url' => 'https://127.0.0.1/',
        'amount' => $paisa,
        'purchase_order_id' => uniqid('Order_'),
        'purchase_order_name' => 'Parking Slot Payment',
        'customer_info' => [
            'name' => $vehicleName,
            'email' => 'test@khalti.com', // Replace with actual email if available
            'phone' => $contact
        ]
    ]);

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => KHALTI_API_URL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $requestPayload,
        CURLOPT_HTTPHEADER => [
            'Authorization: Key ' . KHALTI_SECRET_KEY,
            'Content-Type: application/json',
        ],
    ]);

    $response = curl_exec($curl);
    curl_close($curl);

    if ($response) {
        $responseData = json_decode($response, true);
        if (isset($responseData['payment_url'])) {
            header("Location: " . $responseData['payment_url']);
            exit();
        } else {
            die("Failed to initiate payment.");
        }
    } else {
        die("Payment processing failed.");
    }
} else {
    // Insert booking details for other payment methods
    $sqlInsert = "INSERT INTO vehicles1 (slot, vehicleRegNumber, vehicleName, contact, entryDateTime, exitDateTime, paymentMethod, totalAmount, category, booked_date, payment_status)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)";
    $stmtInsert = $conn->prepare($sqlInsert);
    $stmtInsert->bind_param(
        "sssssssdss",
        $slot, $vehicleRegNumber, $vehicleName, $contact,
        $entryDateTime, $exitDateTime, $paymentMethod, $totalAmount,
        $category, $payment_status
    );

    if ($stmtInsert->execute()) {
        echo "<h2>Payment completed successfully via $paymentMethod.</h2>";
        echo "<p>Slot: $slot</p>";
        echo "<p>Vehicle Reg. Number: $vehicleRegNumber</p>";
        echo "<p>Vehicle Name: $vehicleName</p>";
        echo "<p>Contact: $contact</p>";
        echo "<p>Entry Date & Time: $entryDateTime</p>";
        echo "<p>Exit Date & Time: $exitDateTime</p>";
        echo "<p>Total Amount: Rs. " . number_format($totalAmount, 2) . "</p>";

        echo "<p>You will be redirected to the homepage in 5 seconds...</p>";
        echo '<meta http-equiv="refresh" content="5; url=twheel.php">';
    } else {
        echo "Error: " . $stmtInsert->error;
    }

    $stmtInsert->close();
    $conn->close();
}
?>
