<?php
session_start();

// Check if the user is logged in
$username = $_SESSION['username'] ?? null;
if (!$username) {
    die("User not logged in.");
}

// Database connection
$conn = new mysqli("localhost", "root", "", "parking");

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$slot = $_POST['slot'] ?? '';
$vehicle_Number = $_POST['vehicleNumber'] ?? '';
$vehicle_Type = $_POST['vehicle_Type'] ?? '';
$contact = $_POST['contact'] ?? '';
$date = $_POST['date'] ?? '';
$time = $_POST['time'] ?? '';
$category = $_POST['category'] ?? 'Four-Wheeler'; // Default to 'Four-Wheeler'

// Validate required fields
if (empty($slot) || empty($vehicle_Number) || empty($vehicle_Type) || empty($contact) || empty($date) || empty($time)) {
    die("All fields are required.");
}

// Prepare and execute the SQL statement
$sql = "INSERT INTO tvehicle (username, slot, vehicle_Number, vehicle_Type, contact, date, time, category) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error preparing the statement: " . $conn->error);
}

// Bind parameters to the statement
$stmt->bind_param("ssssssss", $username, $slot, $vehicle_Number, $vehicle_Type, $contact, $date, $time, $category);

// Execute the statement and check for errors
if ($stmt->execute()) {
    header("Location: extra.php"); // Redirect upon successful booking
    exit();
} else {
    // Log detailed error message for debugging
    die("Error executing the query: " . $stmt->error);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
