<?php include 'admindash.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Management System - Four-Wheeler Slots</title>
    <style>
        /* Your existing CSS */
        .parking-lot {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 20px;
            padding: 20px;
            row-gap: 50px;
            column-gap: 50px;
        }

        .slot {
            position: relative;
            top: 100px;
            width: 120px;
            height: 50px;
            background-color: #3a3a3a;
            color: white;
            text-align: center;
            border-radius: 8px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        .slot:hover {
            background-color: #4caf50;
        }

        .slot::before, .slot::after {
            content: "";
            position: absolute;
            width: 20px;
            height: 20px;
            background-color: black;
            border-radius: 50%;
            bottom: -12px;
        }

        .slot::before {
            left: 10px;
        }

        .slot::after {
            right: 10px;
        }

        .roof {
            position: absolute;
            top: -15px;
            width: 80px;
            height: 20px;
            background-color: inherit;
            border-radius: 5px;
        }

        .slot.booked {
            background-color: red;
            cursor: not-allowed;
        }

        .slot.available {
            background-color: #3a3a3a;
        }

        .slot.available:hover {
            background-color: #4caf50;
        }

        .tooltip {
            position: absolute;
            top: -60px;
            left: 50%;
            transform: translateX(-50%);
            background-color: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 10px;
            border-radius: 5px;
            font-size: 12px;
            display: none;
            z-index: 1000;
        }

        .slot.booked:hover .tooltip {
            display: block;
        }
    </style>
</head>
<body>

<h2 style="text-align: center; color: black;">Four-Wheeler Parking Slots</h2>

<div class="parking-lot">
<?php
    $conn = new mysqli("localhost", "root", "", "parking");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch current date
    $currentDate = date('Y-m-d');

    // Fetch booked slots with vehicle details
    $result = $conn->query("SELECT slot, entryDateTime, vehicleRegNumber, username, contact FROM vehicles1 WHERE DATE(entryDateTime) >= '$currentDate'");
    $bookedSlots = [];

    while ($row = $result->fetch_assoc()) {
        $bookedSlots[$row['slot']] = [
            'entryDateTime' => $row['entryDateTime'],
            'vehicleRegNumber' => $row['vehicleRegNumber'],
            'username' => $row['username'],
            'contact' => $row['contact'],
        ];
    }

    // Render parking slots
    for ($i = 1; $i <= 25; $i++) {
        $slotId = "Slot $i";
        $isBooked = isset($bookedSlots[$slotId]);
        $slotClass = $isBooked ? 'slot booked' : 'slot available';
        $tooltipContent = $isBooked
            ? "Booked by: " . htmlspecialchars($bookedSlots[$slotId]['username']) . "<br>" .
              "Contact: " . htmlspecialchars($bookedSlots[$slotId]['contact']) . "<br>" .
              "Vehicle No: " . htmlspecialchars($bookedSlots[$slotId]['vehicleRegNumber']) . "<br>" .
              "Until: " . htmlspecialchars($bookedSlots[$slotId]['entryDateTime'])
            : "Available to book";

        // Render each slot
        echo "<div class='$slotClass' onclick='" . ($isBooked ? "" : "openVehicleForm(\"$slotId\")") . "'>";
        echo $slotId;
        if ($isBooked) {
            echo "<div class='tooltip'>$tooltipContent</div>";
        }
        echo "</div>";
    }

    $conn->close();
?>
</div>

<script>
    function openVehicleForm(slot) {
        alert("Booking functionality not implemented yet for: " + slot);
    }
</script>

</body>
</html>
