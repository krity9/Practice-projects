<?php include'index.php' ?>
<?php
// Start session and check user authentication
//session_start();

// Assume user's ID or username is stored in session
if (!isset($_SESSION['username'])) {
    header("Location: homepage.php"); // Redirect to login page
    exit;
}

$username = $_SESSION['username']; // Fetch the username or user ID

// Connect to the database
$conn = new mysqli("localhost", "root", "", "parking");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user parking details
$sql = "SELECT * FROM vehicles1 WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username); // Bind the username as a parameter
$stmt->execute();
$result = $stmt->get_result();

// Close the database connection at the end
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Parking Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 800px;
            margin: 30px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }

        table th {
            background-color: #333;
            color: white;
        }
        table tr{
          color: black;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;

        }

     
        .no-data {
            text-align: center;
            padding: 20px;
            font-size: 16px;
            color: #555;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Your Parking Details</h2>

        <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Slot</th>
                        <th>Vehicle Register Number</th>
                        <th>Vehicle Name</th>
                        <th>entryDateTime</th>
                        <th>exitDateTime</th>
                        <th>Total Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['slot']) ?></td>
                            <td><?= htmlspecialchars($row['vehicleRegNumber']) ?></td>
                            <td><?= htmlspecialchars($row['vehicleName']) ?></td>
                            <td><?= htmlspecialchars($row['entryDateTime']) ?></td>
                            <td><?= htmlspecialchars($row['exitDateTime']) ?></td>
                            <td><?= htmlspecialchars($row['totalAmount']) ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="no-data">No parking details found for your account.</p>
        <?php endif; ?>

        <?php
        // Close database connection
        $stmt->close();
        $conn->close();
        ?>
    </div>
</body>
</html>
