<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Management System - Home</title>
    <style>
        /* Container styling */
        .content {
            margin-right: 220px;
            padding: 20px;
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .content h1{
            color: azure;
        }

        .vehicle-buttons {
            margin-top: 30px;
            display: flex;
            gap: 20px;
        }

        /* Button styling */
        .vehicle-button {
            width: 200px;
            height: 200px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            color: white;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            background-size: contain;
            background-position: center;
            background-repeat: no-repeat;
        }

        /* Car button styling */
        .four-wheeler {
            background-color: #4caf50;
            background-image: url('image/car-icons.jpg'); /* Replace with a car icon */
        }

        /* Bike button styling */
        .two-wheeler {
            background-color: #3b8ad6;
            background-image: url('image/bike-icon.jpg'); /* Replace with a bike icon */
        }

        .vehicle-button:hover {
            filter: brightness(0.9);
        }

        h1 {
            color: #333;
        }
    </style>
</head>
<?php include'admindash.php' ?>
<body>

<!-- Main Content Section -->
<div class="content">
    <h1 color:"white">Select Vehicle Type</h1>
    <div class="vehicle-buttons">
        <!-- Button for 4-Wheeler with Car Icon -->
        <a href="fwheel1.php" class="vehicle-button four-wheeler" title="4-Wheeler"></a>
        
        <!-- Button for 2-Wheeler with Bike Icon -->
        <a href="twheel1.php" class="vehicle-button two-wheeler" title="2-Wheeler"></a>
    </div>
</div>

</body>
</html>
