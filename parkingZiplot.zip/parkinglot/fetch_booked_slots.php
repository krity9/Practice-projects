<?php
$conn = new mysqli("localhost", "root", "", "parking");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check for expired slots and update their status
$currentTime = date('Y-m-d H:i:s');
$conn->query("UPDATE booked_slots SET status = 'expired' WHERE end_time <= '$currentTime'");

// Fetch all booked slots
$result = $conn->query("SELECT slot FROM booked_slots WHERE status = 'booked'");
$bookedSlots = [];
while ($row = $result->fetch_assoc()) {
    $bookedSlots[] = $row['slot'];
}
$conn->close();
?>
