<?php include 'admindash.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking History</title>
    <style>
        /* General body styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        /* Main content area adjustments */
        .main-content {
            margin-left: 250px; /* Same as the sidebar width */
            padding: 20px;
            padding-top: 70px; /* Adjust for topbar height */
            background-color: #f4f4f4;
            min-height: 100vh; /* Ensures it covers the viewport */
            box-sizing: border-box;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        /* Search bar styling */
        .search-container {
            margin: 20px auto;
            text-align: center;
        }

        .search-container input[type="text"] {
            width: 300px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .search-container button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .search-container button:hover {
            background-color: #4caf50;
        }

        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        table th {
            background-color: #333;
            color: white;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #ddd;
        }

        .no-data {
            text-align: center;
            color: #555;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <!-- Main content starts -->
    <div class="main-content">
        <h1>Parking History</h1>

        <!-- Search Bar -->
        <div class="search-container">
            <form method="GET" action="parking_history.php">
                <input type="text" name="search" placeholder="Enter Vehicle Registration Number" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
                <button type="submit">Search</button>
            </form>
        </div>

        <?php
        // Database connection
        $servername = "localhost";
        $username = "root"; // Adjust to your database username
        $password = "";     // Adjust to your database password
        $dbname = "parking";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Handle search query
        $search = $_GET['search'] ?? '';
        $searchQuery = "";
        if (!empty($search)) {
            $searchQuery = "WHERE vehicleRegNumber LIKE '%" . $conn->real_escape_string($search) . "%'";
        }

        // Query to fetch parking history from the vehicles1 table
        $sql = "SELECT * FROM vehicles1 $searchQuery ORDER BY booked_date DESC"; // Adjust the column names as per your table schema
        $result = $conn->query($sql);

        if ($result->num_rows > 0): ?>
            <!-- Display table -->
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Vehicle Number</th>
                        <th>Owner Name</th>
                        <th>Slot Number</th>
                        <th>Booking Date</th>
                        <th>Exit Time</th>
                        <th>Parking Method</th>
                        <th>Category</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch and display each row of data
                    while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']) ?></td>
                            <td><?= htmlspecialchars($row['vehicleRegNumber']) ?></td>
                            <td><?= htmlspecialchars($row['username']) ?></td>
                            <td><?= htmlspecialchars($row['slot']) ?></td>
                            <td><?= htmlspecialchars($row['booked_date']) ?></td>
                            <td><?= htmlspecialchars($row['exitDateTime']) ?></td>
                            <td><?= htmlspecialchars($row['paymentMethod']) ?></td>
                            <td><?= htmlspecialchars($row['category']) ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <!-- Display message if no data is available -->
            <p class="no-data">No parking history available for the given search term.</p>
        <?php
        endif;

        // Close the connection
        $conn->close();
        ?>
    </div>
    <!-- Main content ends -->
</body>
</html>
