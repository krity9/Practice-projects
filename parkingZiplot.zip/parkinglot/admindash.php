<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            display: flex;
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #333;
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
        }

        .sidebar .logo {
            text-align: center;
            padding: 20px 0;
            background-color: #222;
            border-bottom: 1px solid #444;
        }

        .sidebar .logo img {
            width: 100px;
            height: auto;
            border-radius: 50%;
        }

        .sidebar h2 {
            text-align: center;
            margin: 20px 0;
            font-size: 22px;
            color: #4CAF50;
        }

        .sidebar a {
            text-decoration: none;
            color: white;
            padding: 15px 20px;
            font-size: 18px;
            display: block;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        /* Top Navbar */
        .topbar {
            margin-left: 250px; /* Matches sidebar width */
            width: calc(100% - 250px); /* Takes remaining space */
            background-color:#f4f4f4;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
            z-index: 1000;
            box-sizing: border-box; /* Prevent overflow due to padding */
        }

        .topbar .title {
            font-size: 24px;
            color:#333;
            font-weight: bold;
        }

        .topbar .logout {
            background-color: #333;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .topbar .logout:hover {
            background-color: red;
        }

    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <!-- Logo Section -->
    <div class="logo">
        <!-- Replace 'logo.png' with the path to your logo -->
        <img src="image/logo.png" alt="Admin Logo">
        <h2>Admin Dashboard</h2>
    </div>
    
    <!-- Navigation Links -->
    <a href="slot.php">Slots</a>
    <a href="parking_details.php">Parking Details</a>
    <a href="customer_details.php">Customer Details</a>
    <a href="parking_history.php">Parking History</a> 
</div>

<!-- Top Navbar -->
<div class="topbar">
    <div class="title">Parking Lot Management</div>
    <a href="admin_login.php" class="logout">Logout</a>
</div>

</body>
</html>
