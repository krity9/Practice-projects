<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to the login page if not logged in
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Parking Management System</title>
  <style>
    /* Basic reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    }

    /* Background image styling */
    body {
      background: url('image/bg2.avif') no-repeat center center fixed;
      background-size: cover;
      color: #fff;
    }

    /* Navbar styling */
    .navbar {
      background-color: rgba(0, 0, 0, 0.7); /* Semi-transparent background */
      padding: 15px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    /* Logo styling */
    .navbar h1 {
      color: azure;
      font-size: 24px;
      display: flex;
      align-items: center;
    }

    .navbar h1 img {
      height: 30px;
      width: 30px;
      margin-right: 10px;
    }

    .navbar ul {
      list-style: none;
      display: flex;
    }

    .navbar ul li {
      margin-left: 20px;
    }

    .navbar ul li a {
      color: #fff;
      text-decoration: none;
      font-size: 16px;
    }

    .navbar ul li a:hover {
      color: #ffcc00;
    }

  </style>
</head>
<body>

  <!-- Navbar -->
  <div class="navbar">
    <h1><img src="image/logo.png" alt="Logo">Parking Management System</h1>
    <ul>
      <li><a href="home.php">Home</a></li>
      <li><a href="parking_slot.php">Parking Slot</a></li>
      <li><a href="change_profile.php">Change Profile</a></li>
      <li><a href="homepage.php">Logout</a></li>
    </ul>
  </div>

  <h2 style="text-align: center; margin-top: 20px; color:black;">
    Welcome, <?= htmlspecialchars($_SESSION['username']); ?>!
  </h2>

</body>
</html>
