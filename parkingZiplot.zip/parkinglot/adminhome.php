<!DOCTYPE html>
 <html lang="en">
 <head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Parking Management System</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
 </head>
 <style>
    .d-flex nav-items :hover{
        color: blue;
    }
 </style>
 <body>
 
 <div class="d-flex">
   <!-- Sidebar -->
   <div class="bg-dark text-white p-3 vh-100" style="width: 250px;">
     <h4>Admin</h4>
     <ul class="nav flex-column">
       <li class="nav-item">
         <a href="#" class="nav-link text-white">New Slot</a>
       </li>
       <li class="nav-item">
         <a href="#" class="nav-link text-white">Display Slot</a>
       </li>
       <li class="nav-item">
         <a href="#" class="nav-link text-white">Parking Details</a>
       </li>
       <li class="nav-item">
         <a href="#" class="nav-link text-white">Parking History</a>
       </li>
       <li class="nav-item">
         <a href="#" class="nav-link text-white">Search Parking History</a>
       </li>
       <li class="nav-item">
         <a href="#" class="nav-link text-white">Customer Details</a>
       </li>
     
     </ul>
   </div>
   
   <!-- Main Content -->
   <div class="flex-grow-1">
     <!-- Navbar -->
     <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Car Parking Management System</a>
         <a href="#" >Logout</a>
          
          <!-- Three-line button (Hamburger Menu) -->
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#sidebar" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
        </div>
      </nav>
      
   </div>
 </div>
 
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
 </body>
 </html>