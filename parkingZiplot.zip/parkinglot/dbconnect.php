<?php
session_start(); // Start the session if you want to use session variables

// Database connection parameters
$servername = "localhost";
$username = "root"; // Use your database username
$password = "";     // Use your database password
$dbname = "parking";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and retrieve form data
    $username = $conn->real_escape_string($_POST["username"]);
    $name = $conn->real_escape_string($_POST["name"]);
    $place = $conn->real_escape_string($_POST["place"]);
    $contact = $conn->real_escape_string($_POST["contact"]);
    $email = $conn->real_escape_string($_POST["email"]);
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT); // Hash the password

    // Insert user into the database
    $sql = "INSERT INTO users (username, name, place, contact, email, password) VALUES ('$username', '$name', '$place', '$contact', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        // Automatically log the user in
        $_SESSION['username'] = $username;
        $_SESSION['name'] = $name;

        // Redirect to the homepage or dashboard
        header("Location: homepage.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the connection
$conn->close();
?>
