<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Registration</title>
  <style>
main {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  padding-top: 100px;   
}
.registration-form {
  background-color: rgba(114, 113, 113, 0.85);  
  padding: 20px 30px;
  border-radius: 8px;
  width: 400px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
}
.registration-form form div {
  display: flex;
  align-items: center;
  margin-bottom: 15px;
}
.registration-form label {
  width: 30%;   
  font-weight: bold;
  color: #333;
}
.registration-form input {
  width: 70%;   
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}
.registration-form button {
  width: 100%;
  padding: 10px;
  background-color: #333;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
}
.registration-form button:hover {
  background-color: #555;
}
  </style>
</head>
<body>
<?php include'homepage.php' ?>
  <main>
    <div class="registration-form">
        <h2>User Registration</h2>
        <form id="registrationForm" action="dbconnect.php" method="post" onsubmit="return validateForm()">
            <div>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
          </div>
      
          <div>
            <label for="name">Full Name</label>
            <input type="text" id="name" name="name" required>
          </div>
      
          <div>
            <label for="place">Place</label>
            <input type="text" id="place" name="place" required>
          </div>
      
          <div>
            <label for="contact">Contact Number</label>
            <input type="tel" id="contact" name="contact" pattern="[0-9]{10}" required>
          </div>
      
          <div>
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
          </div>
      
          <div>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required minlength="8">
          </div>
      
          <button type="submit">Sign Up</button>
        </form>
      </div>  
  </main>
  <script >
    function validateForm() {
  const username = document.getElementById("username").value;
  const name = document.getElementById("name").value;
  const place = document.getElementById("place").value;
  const contact = document.getElementById("contact").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;


  if (username === "" || name === "" || place === "" || contact === "" || email === "" || password === "") {
    alert("All fields are required.");
    return false;
  }
  if (contact.length !== 10) {
    alert("Contact number must be 10 digits.");
    return false;
  }
  if (password.length < 8) {
    alert("Password must be at least 8 characters long.");
    return false;
  }
  return true; 
}
  </script>
</body>
</html>