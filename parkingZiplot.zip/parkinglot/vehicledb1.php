<?php
session_start();

// Check if the user is logged in
$username = $_SESSION['username'] ?? null;

if (!$username) {
    die("User not logged in.");
}

// Establish a database connection
$conn = new mysqli("localhost", "root", "", "parking");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve and sanitize POST data
$slot = $_POST['slot'] ?? '';
$vehicleRegNumber = $_POST['vehicleRegNumber'] ?? '';
$vehicleName = $_POST['vehicleName'] ?? '';
$contact = $_POST['contact'] ?? '';
$entryDateTime = $_POST['entryDateTime'] ?? '';
$exitDateTime = $_POST['exitDateTime'] ?? '';
$paymentMethod = $_POST['paymentMethod'] ?? '';
$totalAmount = $_POST['totalAmount'] ?? null;
$category = isset($_POST['category']) ? $_POST['category'] : 'Two-Wheeler';

// Validate required fields
if (empty($slot) || empty($vehicleRegNumber) || empty($vehicleName) || empty($contact) || empty($entryDateTime) || empty($exitDateTime) || empty($paymentMethod) || $totalAmount === null) {
    die("All fields are required, including the total amount.");
}

// Validate date and time
if (strtotime($exitDateTime) <= strtotime($entryDateTime)) {
    die("Exit date-time must be after entry date-time.");
}

$payment_status = ($paymentMethod === 'cash') ? 'paid' : 'unpaid';

// Check for slot availability during the specified time
$sqlCheck = "SELECT * FROM vehicles1 WHERE slot = ? AND entryDateTime < ? AND exitDateTime > ?";
$stmtCheck = $conn->prepare($sqlCheck);
$stmtCheck->bind_param("sss", $slot, $exitDateTime, $entryDateTime);
$stmtCheck->execute();
$resultCheck = $stmtCheck->get_result();

if ($resultCheck->num_rows > 0) {
    die("The selected slot is already booked for the specified time.");
}

// Insert booking details into the database
$sqlInsert = "INSERT INTO vehicles1 (username, slot, vehicleRegNumber, vehicleName, contact, entryDateTime, exitDateTime, paymentMethod, totalAmount,category, booked_date, payment_status)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?, NOW(),?)";
$stmtInsert = $conn->prepare($sqlInsert);
$stmtInsert->bind_param("ssssssssdss", $username, $slot, $vehicleRegNumber, $vehicleName, $contact, $entryDateTime, $exitDateTime, $paymentMethod, $totalAmount,$category,$payment_status);

if ($stmtInsert->execute()) {
    header("Location: twheel.php");
    exit();
} else {
    echo "Error: " . $stmtInsert->error;
}

// Close the database connection
$conn->close();
?>
