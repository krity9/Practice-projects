<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - Parking Management System</title>
  <style>
    #login-form {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      background-color: rgba(0, 0, 0, 0.7);
    }
    .login-content {
      background-color: rgba(94, 92, 92, 0.8);
      padding: 20px;
      border-radius: 8px;
      width: 350px;
      color: white;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
    }
    .login-content h2 {
      margin-bottom: 20px;
      color: #dadada;
    }
    .login-content input {
      width: 100%;
      padding: 8px;
      margin-bottom: 15px;
      border: 1px solid #a8a8a8;
      border-radius: 4px;
    }
    .login-content button {
      width: 100%;
      padding: 10px;
      background-color: #333;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .login-content button:hover {
      background-color: #555;
    }
    .error {
      color: red;
      margin-bottom: 15px;
      text-align: center;
    }
  </style>
</head>
<body>
  <?php include 'homepage.php'; ?>

  <div id="login-form">
    <div class="login-content">
      <h2>User Login</h2>
      
      <?php
      session_start();
      $error = "";
      // Database connection parameters
      $servername = "localhost";
      $username = "root"; // Use your database username
      $password = "";     // Use your database password
      $dbname = "parking";

      // Create a connection
      $conn = new mysqli($servername, $username, $password, $dbname);

      // Check the connection
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      }

      // Handle form submission
      if ($_SERVER["REQUEST_METHOD"] == "POST") {
          // Retrieve and sanitize form data
          $username = $conn->real_escape_string($_POST["username"]);
          $password = $_POST["password"];

          // Query to check if the username exists
          $sql = "SELECT * FROM users WHERE username='$username'";
          $result = $conn->query($sql);

          if ($result->num_rows > 0) {
              $row = $result->fetch_assoc();

              // Verify the password
              if (password_verify($password, $row["password"])) {
                  // Start a session and set the user as logged in
                  $_SESSION["username"] = $username;
                  header("Location: home.php");
                  exit();
              } else {
                  $error = "Invalid username or password.";
              }
          } else {
              $error = "Invalid username or password.";
          }
      }

      // Close the connection
      $conn->close();
      ?>

      <?php if (!empty($error)) : ?>
        <p class="error"><?php echo $error; ?></p>
      <?php endif; ?>

      <form method="POST" action="">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" required>
        
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>
        
        <button type="submit">Login</button>
      </form>
<a href="admin_login.php" style="color:aliceblue">Admin Login</a>

      <p>Don't have an account? <a href="register.php" style="color:#db5f25">User Registration</a></p>
    </div>
  </div>
</body>
</html>
