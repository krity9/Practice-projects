<?php include 'index.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Management System - Two-Wheeler Slots</title>
    <style>
        /* Parking Lot Grid */
        .parking-lot {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 20px;
    row-gap: 80px;
    padding: 20px;
}

/* Styling for each parking slot (Four-Wheeler Shape) */
.slot {
    position: relative;
    width: 120px; /* Increased width for a car shape */
    height: 50px; /* Increased height for a car shape */
    background-color: #3a3a3a;
    color: white;
    text-align: center;
    border-radius: 8px; /* Rounded corners */
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s ease;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); /* Shadow for 3D effect */
}

/* Hover Effect */
.slot:hover {
    background-color: #4caf50;
}

/* Wheels (Four total: two on each side) */
.slot::before, .slot::after {
    content: "";
    position: absolute;
    width: 20px;
    height: 20px;
    background-color: black;
    border-radius: 50%; /* Circular wheels */
    bottom: -12px;
}

/* Front wheels */
.slot::before {
    left: 10px; /* Position for the front wheel */
}

/* Rear wheels */
.slot::after {
    right: 10px; /* Position for the rear wheel */
}

/* Roof or Window */
.roof {
    position: absolute;
    top: -15px; /* Adjust to position it above the slot box */
    width: 80px; /* Smaller width for the roof */
    height: 20px; /* Height of the roof */
    background-color: inherit;
        border-radius: 5px; /* Rounded edges for aesthetics */
}

/* Booked slot styling */
.slot.booked {
    background-color: red; /* Color for booked slots */
    cursor: not-allowed;
}

/* Available slot styling */
.slot.available {
    background-color: #3a3a3a; /* Default color for available slots */
}

.slot.available:hover {
    background-color: #4caf50; /* Highlight on hover */
}

/* Tooltip for booked slots */
.tooltip {
    position: absolute;
    top: -25px;
    background-color: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 5px;
    border-radius: 3px;
    font-size: 12px;
    display: none;
}

.slot.booked:hover .tooltip {
    display: block;
}
        /* Form Styling */
        .form-container {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: rgba(94, 92, 92, 0.9);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            color: white;
            z-index: 1000;
            width: 400px;
            max-width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .form-container input, .form-container select, .form-container button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            background: white;
            color: black;
        }

        .form-container button {
            background-color: #333;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }

        .form-container button:hover {
            background-color: #555;
        }

    
    </style>
</head>

<body>

<h2 style="text-align: center;">Two-Wheeler Parking Slots</h2>

<div class="parking-lot">
<?php
    // Database connection
    $conn = new mysqli("localhost", "root", "", "parking");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the current date
    $currentDate = date('Y-m-d');

    // Fetch booked slots with a valid date
    $result = $conn->query("SELECT slot, booking_date FROM vehicles1 WHERE booking_date >= '$currentDate'");
    $bookedSlots = [];

    // Store booked slots and their booking dates
    while ($row = $result->fetch_assoc()) {
        $bookedSlots[$row['slot']] = $row['booking_date'];
    }

    // Render parking slots
    for ($i = 1; $i <= 25; $i++):
        $slotId = "Slot $i";
        $isBooked = isset($bookedSlots[$slotId]);
        $slotClass = $isBooked ? 'slot booked' : 'slot available';
        $onclick = $isBooked ? '' : "onclick=\"openVehicleForm('$slotId')\"";
    ?>
<div class="<?= $slotClass ?>" <?= $onclick ?> title="<?= $isBooked ? 'Slot is booked' : 'Click to book' ?>">
    <div class="roof"></div> <!-- Roof or window for the car -->
    <?= $slotId ?>
    <?php if ($isBooked): ?>
        <div class="tooltip">Booked until <?= $bookedSlots[$slotId] ?></div>
    <?php endif; ?>
</div>

    <?php endfor; ?>

    <?php $conn->close(); ?>
</div>
<!-- Vehicle Form -->
<div id="vehicleForm" class="form-container">
    <h3>Vehicle Details</h3>
    <form id="vehicleDetailsForm">
        <input type="hidden" id="selectedSlot" name="slot">
        <label for="vehicleRegNumber">Vehicle Register Number</label>
        <input type="text" id="vehicleRegNumber" name="vehicleRegNumber" required>
        <label for="vehicleName">Vehicle Name</label>
        <input type="text" id="vehicleName" name="vehicleName" required>
        <label for="contact">Contact</label>
        <input type="text" id="contact" name="contact" required>
        <label for="date">Date</label>
        <input type="date" id="date" name="date" required>
        <label for="entryTime">Entry Time</label>
        <input type="time" id="entryTime" name="entryTime" required>
        <label for="exitTime">Exit Time</label>
        <input type="time" id="exitTime" name="exitTime" required>
        <label for="totalAmount">Total Amount (Rs.)</label>
        <input type="text" id="totalAmount" name="totalAmount" readonly>
        <button type="button" onclick="calculateAmount()">Calculate Amount</button>
        <button type="button" onclick="openPaymentForm()">Next</button>
        <button type="button" onclick="closeForm('vehicleForm')">Cancel</button>
    </form>
</div>

<!-- Payment Form -->
<div id="paymentForm" class="form-container">
    <h3>Payment Method</h3>
    <form id="paymentDetailsForm" action="vehicledb.php" method="POST">
        <input type="hidden" id="finalSlot" name="slot">
        <input type="hidden" id="finalVehicleRegNumber" name="vehicleRegNumber">
        <input type="hidden" id="finalVehicleName" name="vehicleName">
        <input type="hidden" id="finalContact" name="contact">
        <input type="hidden" id="finalDate" name="date">
        <input type="hidden" id="finalTime" name="time">
        <label for="paymentMethod">Select Payment Method:</label>
        <select id="paymentMethod" name="paymentMethod" onchange="updateFormAction()" required>
        <option value="Cash">Cash</option>
        <option value="eSewa">khalti</option>
        </select>
        <div id="cashMessage" style="display: none; margin-top: 15px; background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px;">
            Please pay the parking fee at the counter.
        </div>
        <button type="submit">Submit Booking</button>
        <button type="button" onclick="closeForm('paymentForm')">Cancel</button>
    </form>
</div>

<script>
function calculateAmount() {
        const entryTime = document.getElementById('entryTime').value;
        const exitTime = document.getElementById('exitTime').value;

        if (entryTime && exitTime) {
            const entryDate = new Date(`1970-01-01T${entryTime}:00`);
            const exitDate = new Date(`1970-01-01T${exitTime}:00`);

            if (exitDate > entryDate) {
                const duration = (exitDate - entryDate) / (1000 * 60 * 60); // Convert milliseconds to hours
                const ratePerHour = 50; // Example rate per hour
                const totalAmount = Math.ceil(duration) * ratePerHour;

                document.getElementById('totalAmount').value = totalAmount;
            } else {
                alert('Exit time must be after entry time.');
                document.getElementById('totalAmount').value = '';
            }
        } else {
            alert('Please fill both entry and exit times.');
        }
    }



    function updateFormAction() {
        const paymentMethod = document.getElementById('paymentMethod').value;
        const paymentForm = document.getElementById('paymentDetailsForm');
        const cashMessage = document.getElementById('cashMessage');

        if (paymentMethod === 'eSewa') {
            paymentForm.action = 'payment_process.php'; // Link to Khalti payment process file
            cashMessage.style.display = 'none'; // Hide cash message
        } else if (paymentMethod === 'Cash') {
            paymentForm.action = 'vehicledb.php'; // Default action for cash payment
            cashMessage.style.display = 'block'; // Show cash message
        }
    }



    function openPaymentForm() {
        // Copy values from vehicle form to payment form
        document.getElementById('finalSlot').value = document.getElementById('selectedSlot').value;
        document.getElementById('finalVehicleRegNumber').value = document.getElementById('vehicleRegNumber').value;
        document.getElementById('finalVehicleName').value = document.getElementById('vehicleName').value;
        document.getElementById('finalContact').value = document.getElementById('contact').value;
        document.getElementById('finalDate').value = document.getElementById('date').value;
        document.getElementById('finalTime').value = document.getElementById('entryTime').value;

        // Add calculated total amount to the payment form
        const totalAmount = document.getElementById('totalAmount').value;
        if (!totalAmount) {
            alert('Please calculate the total amount before proceeding.');
            return;
        }

        const paymentForm = document.getElementById('paymentDetailsForm');
        const amountField = document.createElement('input');
        amountField.type = 'hidden';
        amountField.name = 'totalAmount';
        amountField.value = totalAmount;
        paymentForm.appendChild(amountField);

        document.getElementById('vehicleForm').style.display = 'none';
        document.getElementById('paymentForm').style.display = 'block';
    }
    function openVehicleForm(slot) {
        document.getElementById('selectedSlot').value = slot;
        document.getElementById('vehicleForm').style.display = 'block';
    }
    function closeForm(formId) {
        document.getElementById(formId).style.display = 'none';
    }
</script>

</body>
</html>