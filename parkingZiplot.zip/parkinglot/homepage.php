<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Parking Management System</title>
  <style>
    * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  font-family: Arial, sans-serif;
  background-image: url('image/bg2.avif');
  background-size: cover;
  background-attachment: fixed;
  background-position: center;
}
header {
  background-color: rgba(0, 0, 0, 0.6);
  padding: 10px;
  position: fixed;
  width: 100%;
  top: 0;
  z-index: 1000;
}
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.logo {
  display: flex;
  align-items: center;
  gap: 10px;
  color:white;
}
.logo-img {
  width: 40px;
  height: 40px;
}
.navbar nav ul {
  list-style-type: none;
  display: flex;
  gap: 20px;
}
.navbar nav ul li a {
  color: white; 
  text-decoration: none;
  padding: 8px 16px;
  transition: color 0.3s ease;  
}
.navbar nav ul li a:hover {
  color: #4f7ebd; 
}
  </style>
</head>
<body>
  <header>
  <div class="navbar">
    <div class="logo">
      <img src="image/logo.png" alt="Logo" class="logo-img">
      Parking Management System
    </div>
    <nav>
      <ul>
        <li><a href="main.php">Home</a></li>
        <li><a href="admin_login.php">Admin</a></li>
        <li><a href="login.php">User</a></li>  
      </ul>
    </nav>
  </div>
</header>
</body>
</html>
