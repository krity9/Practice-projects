<?php
// Database connection
$host = "localhost";
$dbname = "parking";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session for login state
session_start();

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputUsername = $_POST['username'];
    $inputPassword = $_POST['password'];

    // Check if username exists
    $stmt = $conn->prepare("SELECT password FROM admins WHERE username = ?");
    $stmt->bind_param("s", $inputUsername);
    $stmt->execute();
    $stmt->bind_result($storedPassword);
    $stmt->fetch();
    $stmt->close();

    // Validate password
    if ( $inputPassword === $storedPassword) {
        // Success: Set session variables and redirect
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $inputUsername;
        header("Location: admindash.php");
        exit();
    } else {
        // Failure: Redirect with error
        $_SESSION['error'] = "Invalid username or password.";
        header("Location: admin_login.php");
        exit();
    }
}
?>
