<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "parking");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if vehicle_id is set in POST
if (isset($_POST['vehicle_id'])) {
    $vehicle_id = intval($_POST['vehicle_id']);

    // Prepare and execute the delete query
    $sql = "DELETE FROM vehicles WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $vehicle_id);

    if ($stmt->execute()) {
        echo "<script>
                window.location.href = 'parking_details.php';
              </script>";
    } else {
        echo "<script>
                alert('Error deleting record: " . $stmt->error . "');
                window.location.href = 'parking_details.php';
              </script>";
    }

    $stmt->close();
}

$conn->close();
?>
