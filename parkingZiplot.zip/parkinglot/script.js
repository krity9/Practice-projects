function updateSlots() {
  fetch('fetch_slots.php')
      .then(response => response.json())
      .then(data => {
          const slots = document.querySelectorAll('.slot');
          slots.forEach(slot => {
              if (data.bookedSlots.includes(slot.id)) {
                  slot.classList.add('booked');
                  slot.onclick = null;
              } else {
                  slot.classList.remove('booked');
                  slot.onclick = () => openVehicleForm(slot.id);
              }
          });
      })
      .catch(error => console.error('Error fetching slots:', error));
}

// Call updateSlots periodically to refresh booked slots
setInterval(updateSlots, 30000); // Update every 30 seconds
